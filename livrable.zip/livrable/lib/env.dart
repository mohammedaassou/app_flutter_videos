const pexelsApiKey = "43265810-669ab75980530033e588c588c&";

/// Pexels Video API base URL.
const pexelsBaseUrl = 'https://pixabay.com/api/videos';
